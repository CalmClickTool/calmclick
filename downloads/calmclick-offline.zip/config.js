﻿/* Bundled with offline zip */
window.CALMCLICK_CONFIG = {
  version: "1.1.0",
  chromeStoreUrl: "",
  localZipUrl: "#",
  extensionZipUrl: "#",
  githubUrl: "https://github.com/CalmClickTool/calmclick",
  rulesFeedUrl: "https://calmclicktool.github.io/calmclick/updates/rules-latest.json"
};
